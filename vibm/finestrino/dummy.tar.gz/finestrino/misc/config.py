import os 

from dynaconf import settings

print (settings.administrators)