from dynaconf import settings

print (settings.HOST)